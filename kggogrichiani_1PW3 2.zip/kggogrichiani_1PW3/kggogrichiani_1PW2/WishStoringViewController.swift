//
//  WishStoringViewController.swift
//  kggogrichiani_1PW2
//
//  Created by MacBook Pro  on 10.11.23.
//

import UIKit

final class WishStoringViewController: UIViewController {
    override func viewDidLoad() {
        view.backgroundColor = .blue
        configureTable()
        table.register(AddWishCell.self, forCellReuseIdentifier: AddWishCell.reuseId)
        table.register(WrittenWishCell.self, forCellReuseIdentifier: WrittenWishCell.reuseId)
        // Do any additional setup after loading the view.
        
        let but: UIButton = UIButton(type: .system)
        view.addSubview(but)
        but.titleLabel?.text = "efuufe"
        //but.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        //but.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
    
    private let table: UITableView = UITableView(frame: .zero)
    private func configureTable() {
        view.addSubview(table)
        table.backgroundColor = .red
        table.dataSource = self
        table.separatorStyle = .none
        table.layer.cornerRadius = 5
        
        table.pinCenterX(to: view)
        table.pinCenterY(to: view)
        table.pinHeight(to: view, 0.8)
        table.pinWidth(to: view, 0.8)
        
        view.addSubview(difBut)
        table.register(WrittenWishCell.self, forCellReuseIdentifier: WrittenWishCell.reuseId)
    }
    
    private var wishArray: [String] = ["I wish to add cells to the table"]
    
    private let addWishCell: AddWishCell = AddWishCell()
    
    
    private let difBut: UIButton = UIButton(frame: CGRect(x: 10, y: 10, width: 100, height: 100))

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

// MARK: - UITableViewDataSource
extension WishStoringViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return wishArray.count
        //return 0
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(
            withIdentifier: AddWishCell.reuseId,
            for: indexPath
            )
            
            guard let addCell = cell as? AddWishCell else { return cell }
            print("MORON")
            return addCell
        }
        
        let cell = tableView.dequeueReusableCell(
        withIdentifier: WrittenWishCell.reuseId,
        for: indexPath
        )
        
        guard let wishCell = cell as? WrittenWishCell else { return cell }
        wishCell.configure(with: wishArray[indexPath.row])
        return wishCell
        //return UITableViewCell()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    
}
