//
//  ViewController.swift
//  kggogrichiani_1PW2
//
//  Created by MacBook Pro  on 04.10.23.
//

import UIKit

// MARK: Constants

enum Constants {
    static let sliderMin: Double = 0
    static let sliderMax: Double = 1
    static let red: String = "Red"
    static let green: String = "Green"
    static let blue: String = "Blue"
    static let stackRadius: CGFloat = 20
    static let stackBottom: CGFloat = -20
    static let stackLeading: CGFloat = 20
    static let fontSize: Double = 32
    static let titleFontSize: Double = 48
    static let titleLeadingConst: CGFloat = 20
    static let titleTopConst: CGFloat = 30
    static let descTopConst: CGFloat = 80
    static let descLeadingConst: CGFloat = 20
    static let titleViewLeadingConst: CGFloat = 20
    static let titleViewTopConst: CGFloat = 10
    static let sliderLeadingConst: CGFloat = 20
    static let sliderBottomConst: CGFloat = -10
    static let redValue: CGFloat = 0.8
    static let greenValue: CGFloat = 0.2
    static let blueValue: CGFloat = 0.5
    static let maxColor: Int = 256
    
    static let wishMakerButtonWidth: CGFloat = 200
    static let wishMakerButtonHeight: CGFloat = 50
    static let buttonHeight: CGFloat = 20
    static let buttonBottom: CGFloat = 30
    static let buttonSide: CGFloat = 0
    static let buttonWidth: CGFloat = 0.8
    static let buttonRadius: CGFloat = 4
    static let buttonText: String = "qwerty"
    
    static let stackTag = 500
    static let redTag = 501
    static let greenTag = 502
    static let blueTag = 503
    
    static let offset: CGFloat = 10
    static let cornerRadius: CGFloat = 4
    static let backgroundColor = UIColor.brown
    static let titleTop: CGFloat = 6
    static let titleFont: UIFont = .boldSystemFont(ofSize: 8)
    static let titleLeading: CGFloat = 8
}

// MARK: Slider class

final class CustomSlider: UIView {
    var valueChanged: ((Double) -> Void)?

    var slider = UISlider()
    var titleView = UILabel()

    init(title: String, min: Double, max: Double) {
        super.init(frame: .zero)
        titleView.text = title
        slider.minimumValue = Float(min)
        slider.maximumValue = Float(max)
        slider.addTarget(self, action: #selector(sliderValueChanged), for: .valueChanged)
        configureUI()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: Configure UI in slider class

    private func configureUI() {
        backgroundColor = .white
        translatesAutoresizingMaskIntoConstraints = false

        for view in [slider, titleView] {
            addSubview(view)
            view.translatesAutoresizingMaskIntoConstraints = false
        }

        NSLayoutConstraint.activate([
            titleView.centerXAnchor.constraint(equalTo: centerXAnchor),
            titleView.topAnchor.constraint(equalTo: topAnchor, constant: Constants.titleViewTopConst),
            titleView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: Constants.titleViewLeadingConst),

            slider.topAnchor.constraint(equalTo: titleView.bottomAnchor),
            slider.centerXAnchor.constraint(equalTo: centerXAnchor),
            slider.bottomAnchor.constraint(equalTo: bottomAnchor, constant: Constants.sliderBottomConst),
            slider.leadingAnchor.constraint(equalTo: leadingAnchor, constant: Constants.sliderLeadingConst)
        ])
    }

    @objc
    private func sliderValueChanged() {
        valueChanged?(Double(slider.value))
    }
}

// MARK: View controller

final class WishMakerViewController : UIViewController {
    
    // Welcome to the WishMakerViewController!
    // It makes wishes!
    
    // More specifically it has 3 sliders that change the background color and some other nonsense!
    // (I am not sure if this is what was meant)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }
    
    private func configureUI() {
        view.backgroundColor = UIColor(
            red: Constants.redValue,
            green: Constants.greenValue,
            blue: Constants.blueValue,
            alpha: 1
        )
        
        configureTitle()
        configureDesc()
        configureAddWishButton()
        configureSliders()
        configureButton()
        configureScheduleWishButton()
    }
    
    // MARK: Button configure
    
    private func configureButton() {
        let button1 = UIButton()
        button1.setTitle("Toggle sliders", for: .normal)
        button1.addTarget(self, action: #selector(toggleSliders), for: .touchUpInside)
        
        let button2 = UIButton()
        button2.setTitle("Randomize", for: .normal)
        button2.addTarget(self, action: #selector(switchColor), for: .touchUpInside)
        
        for button in [button1, button2] {
            button.translatesAutoresizingMaskIntoConstraints = false
            button.titleLabel?.font = UIFont.systemFont(ofSize: Constants.fontSize)
            button.setTitleColor(.black, for: .normal)
            button.backgroundColor = .white
            button.layer.cornerRadius = 10
            view.addSubview(button)
            NSLayoutConstraint.activate([
                button.widthAnchor.constraint(greaterThanOrEqualToConstant: Constants.wishMakerButtonWidth),
                button.heightAnchor.constraint(greaterThanOrEqualToConstant: Constants.wishMakerButtonHeight)
            ])
        }
        
        button1.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        button1.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -30).isActive = true
        
        button2.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        button2.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 30).isActive = true
        
    }
    
    @IBAction func toggleSliders() {
        let stack = view.viewWithTag(Constants.stackTag)
        stack?.isHidden = !stack!.isHidden
    }
    
    @IBAction func switchColor() {
        let r = CGFloat(Int.random(in: 0...Constants.maxColor)) / CGFloat(Constants.maxColor)
        let g = CGFloat(Int.random(in: 0...Constants.maxColor)) / CGFloat(Constants.maxColor)
        let b = CGFloat(Int.random(in: 0...Constants.maxColor)) / CGFloat(Constants.maxColor)
        
        view.backgroundColor = UIColor(displayP3Red: r, green: g, blue: b, alpha: 1)
        
        let stack = view.viewWithTag(Constants.stackTag)
        (stack?.viewWithTag(Constants.redTag) as! CustomSlider).slider.setValue(Float(r), animated: true)
        (stack?.viewWithTag(Constants.greenTag) as! CustomSlider).slider.setValue(Float(g), animated: true)
        (stack?.viewWithTag(Constants.blueTag) as! CustomSlider).slider.setValue(Float(b), animated: true)
    }
    
    // MARK: Title configure
    
    private func configureTitle() {
        let title = UILabel()
        title.translatesAutoresizingMaskIntoConstraints = false
        title.text = "WishMaker"
        title.font = UIFont.systemFont(ofSize: Constants.titleFontSize)
        
        view.addSubview(title)
        NSLayoutConstraint.activate([
            title.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            //title.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.titleLeadingConst),
            title.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: Constants.titleTopConst)
        ])
    }
    
    private func configureDesc() {
        let desc = UILabel()
        desc.translatesAutoresizingMaskIntoConstraints = false
        desc.text = "Change the background \ncolor to your \nheart's content"
        desc.font = UIFont.systemFont(ofSize: Constants.fontSize)
        desc.numberOfLines = 0
    
        
        view.addSubview(desc)
        NSLayoutConstraint.activate([
            desc.leftAnchor.constraint(equalTo: view.leftAnchor, constant: Constants.descLeadingConst),
            desc.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: Constants.descTopConst)
        ])
    }
    
    // MARK: Sliders configure
    
    private func configureSliders() {
        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .vertical
        stack.tag = Constants.stackTag
        view.addSubview(stack)
        stack.layer.cornerRadius = Constants.stackRadius
        stack.clipsToBounds = true
        //
        let sliderRed = CustomSlider(title: Constants.red, min: Constants.sliderMin, max: Constants.sliderMax)
        let sliderGreen = CustomSlider(title: Constants.green, min: Constants.sliderMin, max: Constants.sliderMax)
        let sliderBlue = CustomSlider(title: Constants.blue, min: Constants.sliderMin, max: Constants.sliderMax)
        
        sliderRed.slider.setValue(Float(Constants.redValue), animated: true)
        sliderGreen.slider.setValue(Float(Constants.greenValue), animated: true)
        sliderBlue.slider.setValue(Float(Constants.blueValue), animated: true)
        
        sliderRed.tag = Constants.redTag
        sliderGreen.tag = Constants.greenTag
        sliderBlue.tag = Constants.blueTag
        
        for slider in [sliderRed, sliderGreen, sliderBlue] {
            stack.addArrangedSubview(slider)
        }
        
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.stackLeading),
            stack.bottomAnchor.constraint(equalTo: addWishButton.topAnchor, constant: Constants.stackBottom)
        ])
        
        var r : CGFloat = 0
        var g : CGFloat = 0
        var b : CGFloat = 0
        var a : CGFloat = 0

        sliderRed.valueChanged = {  value in
            self.view.backgroundColor?.getRed(&r, green: &g, blue: &b, alpha: &a)
            self.view.backgroundColor = UIColor(
                red: value,
                green: g,
                blue: b,
                alpha: a)
        }
        
        sliderGreen.valueChanged = { [weak self] value in
            self?.view.backgroundColor?.getRed(&r, green: &g, blue: &b, alpha: &a)
            self?.view.backgroundColor = UIColor(
                red: r,
                green: value,
                blue: b,
                alpha: a)
        }
        
        sliderBlue.valueChanged = { [weak self] value in
            self?.view.backgroundColor?.getRed(&r, green: &g, blue: &b, alpha: &a)
            self?.view.backgroundColor = UIColor(
                red: r,
                green: g,
                blue: value,
                alpha: a)
        }
    }
    
    // MARK: New code
    
    private let addWishButton: UIButton = UIButton(type: .system)
    
    private let scheduleWishButton: UIButton = UIButton(type: .system)
    
    private let tv: UITextView = UITextView(frame: CGRect(x: 50, y: 50, width: 60, height: 60))
    
    
    private let button: UIButton = UIButton(type: .system)
    
    
    private let difBut: UIButton = UIButton(frame: CGRect(x: 10, y: 10, width: 100, height: 100))
    
    private func configureScheduleWishButton() {
        view.addSubview(scheduleWishButton)
        scheduleWishButton.setHeight(Constants.buttonHeight)
        scheduleWishButton.pinBottom(to: addWishButton, Constants.buttonBottom)
        scheduleWishButton.pinCenterX(to: view, Constants.buttonSide)
        scheduleWishButton.pinWidth(to: view, Constants.buttonWidth)
        scheduleWishButton.backgroundColor = .lightGray
        scheduleWishButton.setTitleColor(.systemPink, for: .normal)
        scheduleWishButton.setTitle(Constants.buttonText, for: .normal)
        scheduleWishButton.layer.cornerRadius = Constants.buttonRadius
        scheduleWishButton.addTarget(self, action: #selector(scheduleWishButtonPressed), for: .touchUpInside)
    }
    
    private func configureAddWishButton() {
        view.addSubview(difBut)
        view.addSubview(addWishButton)
        addWishButton.setHeight(Constants.buttonHeight)
        addWishButton.pinBottom(to: view, Constants.buttonBottom)
        addWishButton.pinCenterX(to: view, Constants.buttonSide)
        addWishButton.pinWidth(to: view, Constants.buttonWidth)
        addWishButton.backgroundColor = .white
        addWishButton.setTitleColor(.systemPink, for: .normal)
        addWishButton.setTitle(Constants.buttonText, for: .normal)
        addWishButton.layer.cornerRadius = Constants.buttonRadius
        addWishButton.addTarget(self, action: #selector(addWishButtonPressed), for: .touchUpInside)
        
        view.addSubview(tv)
        tv.text = "TESTTTT"
        tv.backgroundColor = .cyan
        
        
        
        view.addSubview(button)
        
        button.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        button.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        button.setWidth(80)
        button.setHeight(20)
        //button.pinRight(to: wrap, 10)
        //button.pinWidth(to: wrap, 0.2)
        button.backgroundColor = .yellow
        button.addTarget(self, action: #selector(buttonWasPressed), for: .touchUpInside)
        button.titleLabel?.text = "wdjjd"
        button.titleLabel?.textColor = .black
    }
    
    @objc
    private func buttonWasPressed() {
        print("ABC")
    }
    
    
    @objc
    private func addWishButtonPressed() {
        // this will be done later!
        //WishMakerViewController.dismiss(self)(animated: true, completion: nop)
        //navigationController?.popViewController(animated: true)
        //dismiss()
        present(WishStoringViewController(), animated: true)
        //dismiss(animated: true)
    }
    
    @objc
    private func scheduleWishButtonPressed() {
        let vc = WishCalendarViewController()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func nop() {
        
    }
}



/*
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}
*/
