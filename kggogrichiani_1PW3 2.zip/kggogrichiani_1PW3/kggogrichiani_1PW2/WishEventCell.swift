//
//  WishEventCell.swift
//  kggogrichiani_1PW2
//
//  Created by MacBook Pro  on 06.02.24.
//

import Foundation
import UIKit

final class WishEventModel {
    public let title, description, startDate, endDate: String
    
    public init(title: String, description: String, startDate: String, endDate: String) {
        self.title = title
        self.description = description
        self.startDate = startDate
        self.endDate = endDate
    }
}

final class WishEventCell : UICollectionViewCell {
    static let reuseIdentifier: String = "WishEventCell"
    private let wrapView: UIView = UIView()
    private let titleLabel: UILabel = UILabel()
    private let descriptionLabel: UILabel = UILabel()
    private let startDateLabel: UILabel = UILabel()
    private let endDateLabel: UILabel = UILabel()
    
    // MARK: - Lifecycle
    override init(frame: CGRect) {
        super.init(frame: frame)
        configureWrap()
        configureTitleLabel()
        configureDescriptionLabel()
        configureStartDateLabel()
        configureEndDateLabel()
    }
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    // MARK: - Cell Configuration
    func configure(with event: WishEventModel) {
        titleLabel.text = event.title
        descriptionLabel.text = event.description
        startDateLabel.text = "Start Date: \(event.startDate)"
        endDateLabel.text = "End Date: \(event.endDate)"
    }
    // MARK: - UI Configuration
    private func configureWrap() {
        //print("kei")
        addSubview(wrapView)
        wrapView.pinLeft(to: self, Constants.offset)
        wrapView.layer.cornerRadius = Constants.cornerRadius
        wrapView.backgroundColor = Constants.backgroundColor
    }
    private func configureTitleLabel() {
        //print("kai")
        addSubview(titleLabel)
        titleLabel.textColor = .black
        titleLabel.pinTop(to: wrapView, Constants.titleTop)
        titleLabel.font = Constants.titleFont
        titleLabel.pinLeft(to: wrapView, Constants.titleLeading)
    }
    private func configureDescriptionLabel() {
        //print("kai")
        addSubview(descriptionLabel)
        descriptionLabel.textColor = .black
        descriptionLabel.pinTop(to: titleLabel.bottomAnchor, Constants.titleTop)
        descriptionLabel.font = .italicSystemFont(ofSize: Constants.titleFont.pointSize)
        descriptionLabel.pinLeft(to: wrapView, Constants.titleLeading)
    }
    private func configureStartDateLabel() {
        //print("kai")
        addSubview(startDateLabel)
        startDateLabel.textColor = .black
        startDateLabel.pinTop(to: descriptionLabel.bottomAnchor, Constants.titleTop)
        startDateLabel.font = Constants.titleFont
        startDateLabel.textColor = .green
        startDateLabel.pinLeft(to: wrapView, Constants.titleLeading)
    }
    private func configureEndDateLabel() {
        //print("kai")
        addSubview(endDateLabel)
        endDateLabel.textColor = .black
        endDateLabel.pinTop(to: startDateLabel.bottomAnchor, Constants.titleTop)
        endDateLabel.font = Constants.titleFont
        endDateLabel.textColor = .red
        endDateLabel.pinLeft(to: wrapView, Constants.titleLeading)
    }
    
}
