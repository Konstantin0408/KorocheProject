// Models

import UIKit
/// Модель для передачи данных в VIP цикле
enum HomeModels {

    /// Набор запросов для одного VIP цикла
    enum FetchUser {

        /// Запрос к Interactor из View Controller
        struct Request {
            let userName: String
        }

        /// Запрос к Presentor из Interactor
        struct Response {
            let userPhone: String
            let userEmail: String
        }

        /// Запрос к View Controller из Presentor
        struct ViewModel {
            let userPhone: String
            let userEmail: String
        }
    }
    
    enum FetchPets {

        /// Запрос к Interactor из View Controller
        struct Request {
            let petName: String
        }

        /// Запрос к Presentor из Interactor
        struct Response: Decodable {
            let message: [String]
        }

        /// Запрос к View Controller из Presentor
        struct ViewModel {
            let image: UIImage
        }
    }
}
