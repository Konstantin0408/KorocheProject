//
//  TableViewCell.swift
//  exo
//
//  Created by MacBook Pro  on 19.03.24.
//

import Foundation
import UIKit

class TableViewCell: UITableViewCell {
    public var image: UIImage?
}
