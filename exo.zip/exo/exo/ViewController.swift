
import UIKit

// ViewController
/// Протокол логики для отображения подготовленной информации
protocol HomeDisplayLogic: AnyObject, UITableViewDataSource {

    /// Метод логики отображения данных
    func displayUser(_ viewModel: HomeModels.FetchUser.ViewModel)
    func displayPet(_ viewModel: HomeModels.FetchPets.ViewModel)
}

final class HomeViewController: UIViewController, UITableViewDataSource {
    public var data = ["empty", "empty", "empty"]
    public var images: [UIImageView?] = [nil, nil, nil]
    
    var dogBreeds = ["hound", "pug", "toy poodle", "husky", "pitbull"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch (tableView) {
        case self.tableView:
            return self.data.count
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
        cell.textLabel?.text = self.data[indexPath.row]
        if let imageView = images[indexPath.row] {
            //imageView.removeFromSuperview()
            cell.addSubview(imageView)
            
            imageView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                imageView.leadingAnchor.constraint(equalTo: cell.leadingAnchor, constant: 10),
                imageView.centerYAnchor.constraint(equalTo: cell.centerYAnchor, constant: 0),
                imageView.widthAnchor.constraint(equalToConstant: 70),
                imageView.heightAnchor.constraint(equalToConstant: 70),
            ])
        }
        return cell
    }
    
    /*func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }*/
    
    
    
    var contentView = UIView()
    var tableView = UITableView()
    
    var settingsView = UIView()
    var changeButton = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
    var slider = UISlider()

    /// Ссылка на протокол бизнес логики Interactor'a сцены
    var interactor: HomeBusinessLogic?

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
    super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        setup()
    }

    required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
        setup()
    }

    /// Метод для стартовой настройки компонентов сцены
    private func setup() {
        // Создаем компоненты VIP цикла
        let interactor = HomeInteractor()
        let presenter = HomePresenter()

        // Связываем созданные компоненты
        interactor.presenter = presenter
        presenter.viewController = self

        // Указываем ссылку на Interactor для View Controller
        self.interactor = interactor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        configureContent()
        configureSettings()
    }

    
    func configureContent() {
        view.addSubview(contentView)
        contentView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            contentView.topAnchor.constraint(equalTo: view.topAnchor),
            contentView.bottomAnchor.constraint(equalTo: view.centerYAnchor),
            contentView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        contentView.backgroundColor = .white
        
        configureTable()
    }
    
    func configureTable() {
        tableView.backgroundColor = .systemGreen
        contentView.addSubview(tableView)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tableView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            tableView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            tableView.widthAnchor.constraint(equalTo: contentView.widthAnchor),
            tableView.heightAnchor.constraint(equalTo: contentView.heightAnchor)
        ])
        
        tableView.register(TableViewCell.self, forCellReuseIdentifier: "Cell")
        tableView.dataSource = self
        tableView.rowHeight = 100
        
        tableView.frame = CGRect.init(origin: .zero, size: contentView.frame.size)
    }
    
    
    
    func configureSettings() {
        
        view.addSubview(settingsView)
        settingsView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            settingsView.topAnchor.constraint(equalTo: view.centerYAnchor),
            settingsView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            settingsView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            settingsView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        settingsView.backgroundColor = UIColor(white: 0.5, alpha: 0.5)
        
        
        configureChangeButton()
        configureSlider()
    }
    
    @IBAction func changeButtonPressed(_ sender: UIButton) {
        //(interactor as! HomeInteractor).presenter?.presentPet(HomeModels.FetchPets.Response(message: ["https://images.dog.ceo/breeds/hound-english/n02089973_1492.jpg"]))
        
        let index = Int(arc4random_uniform(UInt32(dogBreeds.count)))
        
        interactor?.fetchPet(HomeModels.FetchPets.Request(petName: dogBreeds[index]))
    }
    
    @IBAction func sliderPulled(_ sender: UISlider) {
        view.backgroundColor = UIColor(white: CGFloat(1 - sender.value * 0.75), alpha: 1)
    }
    
    func configureChangeButton() {
        changeButton.backgroundColor = .systemBlue
        changeButton.setTitle("Change", for: .normal)
        settingsView.addSubview(changeButton)
        changeButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            changeButton.topAnchor.constraint(equalTo: settingsView.topAnchor, constant: 10),
            changeButton.centerXAnchor.constraint(equalTo: settingsView.centerXAnchor),
            changeButton.widthAnchor.constraint(equalToConstant: 100),
            changeButton.heightAnchor.constraint(equalToConstant: 30)
        ])
        
        changeButton.addTarget(self, action: #selector(changeButtonPressed), for: .touchUpInside)
    }
    
    func configureSlider() {
        slider.backgroundColor = .systemBlue
        settingsView.addSubview(slider)
        slider.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            slider.topAnchor.constraint(equalTo: changeButton.bottomAnchor, constant: 10),
            slider.centerXAnchor.constraint(equalTo: settingsView.centerXAnchor),
            slider.widthAnchor.constraint(equalToConstant: 200),
            //slider.heightAnchor.constraint(equalToConstant: 1)
        ])
        
        slider.addTarget(self, action: #selector(sliderPulled), for: .valueChanged)
    }
    
}

/// Подписываем контроллер под протокол HomeDisplayLogic
extension HomeViewController: HomeDisplayLogic {

    public func displayUser(_ viewModel: HomeModels.FetchUser.ViewModel) {
        print(viewModel)
    }
    
    public func displayPet(_ viewModel: HomeModels.FetchPets.ViewModel) {
        let ip = IndexPath(row: 1, section: 0)
        let i = ip.row
        data[i] = "IMAGE SHOULD BE HERE"
        images[i]?.removeFromSuperview()
        images[i] = UIImageView(image: viewModel.image)
        images[i]?.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        //print(viewModel.description)
        let cell = tableView(tableView, cellForRowAt: ip)
        cell.textLabel?.text = data[i]
        
        let imageView = UIImageView(image: viewModel.image)
        imageView.frame = CGRect(x: 0, y: 0, width: 60, height: 60)
        //cell.addSubview(imageView)
        //cell.textLabel?.text = "img"
        
        tableView.reloadRows(at: [ip], with: .fade)
        
    }
}
