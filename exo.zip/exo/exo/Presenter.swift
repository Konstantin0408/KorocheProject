import Foundation
import UIKit
/// Протокол логики презентации
protocol HomePresentationLogic: AnyObject {

    
    func presentPet(_ response: HomeModels.FetchPets.Response)
}

final class HomePresenter: HomePresentationLogic {

  /// Ссылка на логику отображения View Controller'a
    weak var viewController: HomeDisplayLogic?
    
    /*func loadData(url: URL, completion: @escaping (Data?, Error?) -> Void) {
        let fileCachePath = FileManager.default.temporaryDirectory.appendingPathComponent(url.lastPathComponent, isDirectory: false)
        
        let data = try! Data(contentsOf: fileCachePath)
        completion(data, nil)
    }*/

    
    func presentPet(_ response: HomeModels.FetchPets.Response) {
        
        let urlString = response.message[0]
        print(urlString)
        
        let url = URL(string: urlString)
        var viewModel: HomeModels.FetchPets.ViewModel!
        
        
        /*self.loadData(url: url!) { (data, error) in
            if let image = UIImage(data: data!) {
                viewModel = HomeModels.FetchPets.ViewModel(image: image)
            }
        }*/
        
        let task = URLSession.shared.dataTask(with: url!) { data, response, error in
            if (data != nil) {
                
                if let image = UIImage(data: data!) {
                    viewModel = HomeModels.FetchPets.ViewModel(image: image)
                }
                
            } else {
                print("error")
            }
        }
        task.resume()
        while (viewModel == nil) { }
        self.viewController?.displayPet(viewModel)
        
        //let viewModel = HomeModels.FetchPets.ViewModel(description: response.description + " (presented)")
        //viewController?.displayPet(viewModel)
    }
}
