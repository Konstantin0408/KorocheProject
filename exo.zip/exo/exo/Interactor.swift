// Interactor

import Foundation
/// Протокол бизнес логики Interactor'a
protocol HomeBusinessLogic: AnyObject {

    /// Метод получения данных из сети или других источников
    //func fetchUser(_ request: HomeModels.FetchUser.Request)
    func fetchPet(_ request: HomeModels.FetchPets.Request)
}

final class HomeInteractor: HomeBusinessLogic {

    /// Ссылка на логику презентора сцены
    public var presenter: HomePresentationLogic?
    
    //func loadData(url: URL)
    
    
    
    func fetchPet(_ request: HomeModels.FetchPets.Request) {
        
        let name = request.petName
        
        let urlString = "https://dog.ceo/api/breed/\(name)/images/random/1".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        print(urlString)
        let url = URL(string: urlString)
        
        var imageUrls: HomeModels.FetchPets.Response!
        let task = URLSession.shared.dataTask(with: url!) { data, response, error in
            if (data != nil) {
                
                imageUrls = try! JSONDecoder().decode(HomeModels.FetchPets.Response.self, from: data!)
                
            }
        }
        task.resume()
        
        while (imageUrls == nil) { }
        self.presenter?.presentPet(imageUrls)
        
        
        
    }
}
