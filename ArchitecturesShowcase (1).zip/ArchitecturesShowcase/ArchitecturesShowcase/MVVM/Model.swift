//
//  Model.swift
//  ArchitecturesShowcase
//
//  Created by Grigory Sosnovskiy on 17.11.2023.
//

typealias MVVMModel = MVCModel
