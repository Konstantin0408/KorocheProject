//
//  MVCView.swift
//  ArchitecturesShowcase
//
//  Created by Grigory Sosnovskiy on 17.11.2023.
//

import UIKit

final class MVCView: UIView {
    
}
