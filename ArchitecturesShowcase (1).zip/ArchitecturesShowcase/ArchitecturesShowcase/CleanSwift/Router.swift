//
//  Router.swift
//  ArchitecturesShowcase
//
//  Created by MacBook Pro  on 17.11.23.
//

import UIKit

protocol RoutingLogic {
    func goToStart()
}

class Router : RoutingLogic {
    weak var vc : ViewController?
    func goToStart() {
        vc?.present(MVCViewController(), animated: false)
    }
}
