//
//  ViewController.swift
//  ArchitecturesShowcase
//
//  Created by Grigory Sosnovskiy on 17.11.2023.
//

import UIKit

class ViewController: UIViewController {
    weak var object: NSObject?

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

