//
//  ViewController.swift
//  kggogrichiani_1PW1
//
//  Created by MacBook Pro  on 15.09.23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view4: UIView!
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        animate() // I animate everything after loading
    }
    
    /*
    func handleView(view: UIView, color: UIColor) {
        view.backgroundColor = UIColor(
            displayP3Red: .random(in: 0...1), green: .random(in: 0...1), blue: .random(in: 0...1), alpha: 1
            
        )
        view.layer.cornerRadius = .random(in: 0...25)
    }
    */
    
    func randomColor() -> UIColor { // MARK: This function returns a random color in RGB
        return UIColor(displayP3Red: .random(in: 0...1), green: .random(in: 0...1), blue: .random(in: 0...1), alpha: 1) // FIXME: I have no idea how to use a UIColor extension
    }
    
    func animate() { // MARK: Animates everything
        button.isEnabled = false
        
        let animDuration = 0.6
        
        var set = Set<UIColor>()
        let viewsCount = 4
        for _ in 0...viewsCount // MARK: The set is used to make each color unique
        {
            var newColor = randomColor()
            while (set.contains(newColor)) {
                newColor = randomColor()
            }
            set.insert(newColor)
        }
        
        UIView.animate(withDuration: animDuration, animations: { // MARK: Animation starts
            
            let maxRadius = 40.0
            
            self.view1.backgroundColor = set.popFirst()
            self.view1.layer.cornerRadius = .random(in: 0...maxRadius)
            
            self.view2.backgroundColor = set.popFirst()
            self.view2.layer.cornerRadius = .random(in: 0...maxRadius)
            
            self.view3.backgroundColor = set.popFirst()
            self.view3.layer.cornerRadius = .random(in: 0...maxRadius)
            
            self.view4.backgroundColor = set.popFirst()
            self.view4.layer.cornerRadius = .random(in: 0...maxRadius)
            
        },
            completion: { [weak self] _ in
            self?.button.isEnabled = true
        })
    }
    
    @IBAction func buttonWasPressed(_ sender: Any) {
        
        animate()
    }
    

}

