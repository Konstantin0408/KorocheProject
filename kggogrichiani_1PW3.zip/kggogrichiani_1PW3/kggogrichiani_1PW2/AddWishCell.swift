//
//  AddWishCell.swift
//  kggogrichiani_1PW2
//
//  Created by MacBook Pro  on 10.11.23.
//

import UIKit

class AddWishCell: UITableViewCell {
    static let reuseId: String = "AddWishCell"
    
    private enum Constants {
        static let wrapColor: UIColor = .gray
        static let wrapRadius: CGFloat = 16
        static let wrapOffsetV: CGFloat = 5
        static let wrapOffsetH: CGFloat = 10
        static let wishLabelOffset: CGFloat = 8
    }
    
    
    private let input: UITextView = UITextView()//frame: CGRect(x: 10, y: 10, width: 100, height: 100))
    
    //private let button: UIButton = UIButton()
    private let button: UIButton = {
        let control = UIButton()
        control.backgroundColor = UIColor.yellow //white
        control.layer.cornerRadius = 4 // 18
        control.clipsToBounds = false
        control.translatesAutoresizingMaskIntoConstraints = false // required
        control.titleLabel?.text = "wdjjd"
        control.titleLabel?.textColor = .black
        control.addTarget(control, action: #selector(buttonWasPressed), for: .touchUpOutside)
        return control
    }()
    
    var addWish: ((String) -> ())?

    /*override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }*/
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        configureUI()
        print("HERE")
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureUI() {
        selectionStyle = .none
        backgroundColor = .clear
        let wrap: UIView = UIView()
        addSubview(wrap)
        wrap.backgroundColor = Constants.wrapColor
        wrap.layer.cornerRadius = Constants.wrapRadius
        wrap.pinTop(to: self, 0)
        wrap.pinLeft(to: self, 0)
        wrap.pinRight(to: self, 0)
        wrap.pinBottom(to: self, 0)
        
        wrap.addSubview(input)
        input.translatesAutoresizingMaskIntoConstraints = true
        //input.pinLeft(to: wrap)
        //input.pinWidth(to: wrap, 0.5)
        input.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: 20).isActive = true
        input.centerYAnchor.constraint(equalTo: wrap.centerYAnchor).isActive = true
        input.setWidth(80)
        input.setHeight(20)
        input.backgroundColor = .cyan
        input.textColor = .black
        input.isEditable = true
        input.text = "INPUT"
        
        addSubview(button)
        
        button.trailingAnchor.constraint(equalTo: wrap.trailingAnchor, constant: -20).isActive = true
        button.centerYAnchor.constraint(equalTo: wrap.centerYAnchor).isActive = true
        button.setWidth(200)
        button.setHeight(20)
        //button.pinRight(to: wrap, 10)
        //button.pinWidth(to: wrap, 0.2)
        /*button.backgroundColor = .yellow*/
        
        
        
    }
    
    @IBAction
    private func buttonWasPressed() {
        print("ABC")
    }

}
